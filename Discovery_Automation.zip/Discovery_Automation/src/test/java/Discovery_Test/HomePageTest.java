package Discovery_Test;

import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.base.discovery.Base;

import Page_Discovery.HomePage;

public class HomePageTest extends Base 
{
	HomePage home;
	
	@BeforeMethod
	 public void setup()
	 {
		initialization();
		 home = new HomePage();
		
	 }
	
	@Test
	
	public void titletest()
	{
		String ti = home.ValidateTitle();
		Assert.assertEquals(ti, "Discovery");
	}
	
	public void videotest()
	{
		
		boolean b = home.validateVideos();
		
		Assert.assertTrue(b);
	}
	
	@AfterMethod
	public void teardown()
	{
	driver.close();	
		
	}
	
	

}
