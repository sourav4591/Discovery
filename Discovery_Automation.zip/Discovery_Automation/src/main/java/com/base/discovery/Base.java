package com.base.discovery;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Base {
	
	public static WebDriver driver;
	
	public static void initialization()
	{
		 System.setProperty("webdriver.chrome.driver", "C:/Users/sourav.das/Downloads/chromedriver_win32.exe");
		driver = new ChromeDriver();
		driver.get("https://www.discovery.com");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.manage().timeouts().pageLoadTimeout(20, TimeUnit.SECONDS);
		
	}

}
