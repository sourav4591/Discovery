package Page_Discovery;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.base.discovery.Base;


public class HomePage extends Base
{
	
	@FindBy(xpath ="//img[contains(@class , 'm-MediaBlock__a-Image a-Image')]")
	WebElement Trendingvideos;
	
	
	public HomePage()
	{
		PageFactory.initElements(driver, this);
	 	//driver = this.driver;
	}
	
public String ValidateTitle()
{
	return driver.getTitle();
	}


public boolean validateVideos()
{

	boolean flag = Trendingvideos.isDisplayed();
	Trendingvideos.click();
	return flag;

}


}
