package com.discovery.test;

import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.discovery.base.TestBase;
import com.discovery.page.HomePage;

public class HomePageTest extends TestBase {
	
	HomePage home;
	
	
@BeforeMethod
public void Setup()
{
	home = new HomePage();
	initialization();
	
}

@Test
public void Testtitle()
{
String ti = home.validatetitle();
Assert.assertEquals(ti, "Discovery");

}

@Test
public void testvideo()
{
boolean vi = home.validatevideo();
Assert.assertTrue(vi);
}






@AfterMethod
public void Teardown()
{
driver.close();	
}


}
