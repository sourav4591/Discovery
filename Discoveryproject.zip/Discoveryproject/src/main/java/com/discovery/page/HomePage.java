package com.discovery.page;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.discovery.base.TestBase;

public class HomePage extends TestBase {
	

	
	@FindBy(xpath = "//img[contains(@class , 'm-MediaBlock__a-Image a-Image')]")
	WebElement TrendingVideos;
	
	
	public HomePage()
	{
		PageFactory.initElements(driver, this);
		
	}
	
public String validatetitle()
{
String title = driver.getTitle();
return title;
}
	
public boolean validatevideo()
{
boolean b = TrendingVideos.isDisplayed();
return b;
}

	
}
