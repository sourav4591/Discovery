package com.discovery.page;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;



import com.discovery.base.TestBase;

public class HomePage extends TestBase {
	

	@FindBy(xpath = "//*[@id='mod-full-width-strip-1']")
	WebElement fullwidthmod;
	
	@FindBy(xpath = "//a[@href = '//www.discovery.com/shows' and @class = 'o-Header__a-NavLink']")
	WebElement shows;
	
	
	@FindBy(xpath = "//a[@class = 'o-Header__a-NavLink']"
			+ "//following::a[@href ='//www.discovery.com/shows/serengeti' and text() ='Serengeti']")
	WebElement Serengiti;
	
	
	
	@FindBy(xpath = "//a[contains(@title,'MASTERS OF DISASTER: Gibson Girl')] ")
	WebElement TrendingVideos;
	
	
	
	public HomePage()
	{
		PageFactory.initElements(driver, this);
		
	}
	
public String validatetitle()
{
String title = driver.getTitle();
System.out.println(title);
return title;
}

public boolean Clickonshows()
{
	
Actions act = new Actions(driver);
 act.moveToElement(shows).build().perform();
 Serengiti.click();
 
Boolean bg = Serengiti.isDisplayed();


return bg;

}


	
public boolean validatevideo()
{
boolean b = TrendingVideos.isDisplayed();
TrendingVideos.click();
System.out.println("TrendingVideos clicked");
return b;
}

	
}
